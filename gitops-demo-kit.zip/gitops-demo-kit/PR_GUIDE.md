# PR guide – aip-gitops-demo (LP-3818)

## Setup (raz, ok. 10 min)

1. W Bitbuckecie zaloz puste repo `aip-gitops-demo` (bez README i bez .gitignore, musi byc calkiem puste).
2. W Git Bash:
   ```
   git clone <url-repo>/aip-gitops-demo.git
   cd aip-gitops-demo
   bash /sciezka/do/gitops-demo-kit/setup-demo.sh init
   git push -u origin --all
   ```
   Jesli domyslny branch u was to `master`: `BASE_BRANCH=master bash .../setup-demo.sh init`
3. Otworz PR-y z tabeli ponizej (kazdy do `main`). Tytul i opis kopiujesz z sekcji nizej.
4. **Zmerguj PR 3 przed demo** (to "poranna zmiana, ktora zepsula R").
5. Potem `bash .../setup-demo.sh rollback`, `git push -u origin scenario/4-rollback` i otworz PR 4.

## PR-y

| # | Branch | Co zmienia | Kiedy merge |
|---|---|---|---|
| 1 | `scenario/1-promote-r-to-e` | `services.yaml`: genai-execution-service `e: 1.4.2 → 1.5.0` | na zywo |
| 2 | `scenario/2-feature-slot` | dodaje `feature-slots/aiplatform-a/slot.yaml` | na zywo |
| 2b | `scenario/2-release-slot` | usuwa `slot.yaml` (PR otworz dopiero po merge PR 2) | opcjonalnie na zywo |
| 3 | `scenario/3-bad-change` | `services.yaml`: workflow-manager `r: 3.0.2 → 3.1.0` | **przed demo** |
| 4 | `scenario/4-rollback` | revert PR 3: workflow-manager `r: 3.1.0 → 3.0.2` | na zywo |
| 5 | `scenario/5-drift` | dodaje `docs/scenario-5-drift.md` (mock) | nie merguj, tylko branch |

Kolejnosc na demo: 1 → 2 → 3 (blame na main) → 4 → 5 (slajd). PR-y nie koliduja ze soba w tej kolejnosci (sprawdzone).

Jesli wasz Bitbucket ma przycisk **Revert** na zmergowanym PR, mozesz w scenariuszu 4 pokazac ten przycisk zamiast gotowego PR 4.

## Tytuly i opisy do skopiowania

**PR 1 – `e: genai-execution-service 1.5.0 (promote from r)`**
> Promote genai-execution-service 1.5.0 from r to e.
> Tested on r. After merge, Argo CD syncs environment e.

**PR 2 – `aiplatform-a: book feature slot for LAB-123`**
> Book aiplatform-a for LAB-123 until 2026-11-15.
> Services under test: file-watcher 2.4.0-feat, workflow-manager 3.2.0-feat, genai-execution-service 1.6.0-feat. Everything else stays on the baseline (r versions).

**PR 2b – `aiplatform-a: release slot LAB-123 (back to baseline)`**
> LAB-123 is released. Remove the slot so aiplatform-a goes back to the baseline.

**PR 3 – `r: workflow-manager 3.1.0`**
> Promote workflow-manager 3.1.0 to r.

**PR 4 – `Revert "r: workflow-manager 3.1.0"`**
> workflow-manager 3.1.0 breaks the flow on r. Roll back to 3.0.2.
> After merge, Argo CD restores the previous version on r.

## Rzeczy do dopasowania przed demo

- `slot.yaml`: `owner: dev.name` zmien na siebie, a `LAB-123` na dowolny przykladowy ticket.
- Zeby Blame w scenariuszu 3 pokazal kogos innego niz ciebie, popros kolege, zeby zatwierdzil i zmergowal PR 3.
- Wszystkie wersje, hosty i namespace'y to placeholdery. Nie podmieniaj ich na prawdziwe (wymog z ticketu).
