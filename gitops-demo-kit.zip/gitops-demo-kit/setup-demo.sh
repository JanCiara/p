#!/usr/bin/env bash
# Sets up the aip-gitops-demo repo for LP-3818.
#
# Usage (Git Bash), from inside an EMPTY clone of the Bitbucket repo:
#   bash /path/to/gitops-demo-kit/setup-demo.sh init
#   ...push, open PRs, merge scenario/3-bad-change...
#   bash /path/to/gitops-demo-kit/setup-demo.sh rollback
#
# Base branch defaults to "main". Override: BASE_BRANCH=master bash setup-demo.sh init
set -euo pipefail

KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE="${BASE_BRANCH:-main}"
SVC=platform/services.yaml

die() { echo "ERROR: $*" >&2; exit 1; }

# setver <service> <env> <version>: change one version in services.yaml
setver() {
  grep -q "^  $1:\$" "$SVC" || die "service $1 not found in $SVC"
  sed -i.bak "/^  $1:\$/,/^  [a-z]/ s/^    $2: .*/    $2: $3/" "$SVC"
  rm -f "$SVC.bak"
}

commit() { git add -A && git commit -q -m "$1" && echo "  commit: $1"; }

cmd_init() {
  git rev-parse --git-dir >/dev/null 2>&1 || die "run this inside a git clone"
  git rev-parse --verify -q HEAD >/dev/null && die "repo is not empty; run init only on a fresh, empty repo"

  git symbolic-ref HEAD "refs/heads/$BASE"
  cp -R "$KIT/repo/." .

  echo "History on $BASE:"
  # Start from older versions so the history has real bumps.
  setver genai-execution-service r 1.4.2
  setver file-watcher r 2.2.4
  setver file-sender r 2.3.0
  setver file-sender e 2.3.0
  setver workflow-manager r 3.0.1
  commit "Initial layout of the GitOps sample repo"

  setver genai-execution-service r 1.5.0; commit "r: genai-execution-service 1.5.0"
  setver file-watcher r 2.3.0;            commit "r: file-watcher 2.3.0"
  setver file-sender r 2.3.1
  setver file-sender e 2.3.1;             commit "r, e: file-sender 2.3.1"
  setver workflow-manager r 3.0.2;        commit "r: workflow-manager 3.0.2"

  # Sanity check: main now matches the kit's baseline files.
  diff -r -x .git "$KIT/repo" . >/dev/null || die "baseline does not match kit/repo (bug in setup)"

  echo "Scenario branches:"
  git checkout -q -b scenario/1-promote-r-to-e "$BASE"
  setver genai-execution-service e 1.5.0
  commit "e: genai-execution-service 1.5.0 (promote from r)"

  git checkout -q -b scenario/2-feature-slot "$BASE"
  cp "$KIT/extras/slot.yaml" feature-slots/aiplatform-a/slot.yaml
  commit "aiplatform-a: book feature slot for LAB-123"

  git checkout -q -b scenario/2-release-slot scenario/2-feature-slot
  git rm -q feature-slots/aiplatform-a/slot.yaml
  commit "aiplatform-a: release slot LAB-123 (back to baseline)"

  git checkout -q -b scenario/3-bad-change "$BASE"
  setver workflow-manager r 3.1.0
  commit "r: workflow-manager 3.1.0"

  git checkout -q -b scenario/5-drift "$BASE"
  mkdir -p docs
  cp "$KIT/extras/scenario-5-drift.md" docs/scenario-5-drift.md
  commit "docs: drift example (mock)"

  git checkout -q "$BASE"
  cat <<EOF

Done. Next:
  git push -u origin --all
Then open PRs into $BASE (see PR_GUIDE.md) and merge scenario/3-bad-change.
After that run:  bash "$KIT/setup-demo.sh" rollback
EOF
}

cmd_rollback() {
  git checkout -q "$BASE"
  git pull -q --ff-only
  grep -A1 "^  workflow-manager:\$" "$SVC" | grep -q "r: 3.1.0" \
    || die "workflow-manager r is not 3.1.0 on $BASE; merge scenario/3-bad-change first"
  local c
  c="$(git log --no-merges -1 --format=%H -S'3.1.0' -- "$SVC")"
  [ -n "$c" ] || die "could not find the commit that introduced 3.1.0"
  git checkout -q -b scenario/4-rollback
  git revert --no-edit "$c" >/dev/null
  echo "  commit: $(git log -1 --format=%s)"
  git checkout -q "$BASE"
  cat <<EOF

Done. Next:
  git push -u origin scenario/4-rollback
Then open the rollback PR into $BASE (see PR_GUIDE.md).
EOF
}

case "${1:-}" in
  init) cmd_init ;;
  rollback) cmd_rollback ;;
  *) echo "usage: bash setup-demo.sh init|rollback"; exit 1 ;;
esac
