# Feature slots on aiplatform-a

aiplatform-a is a shared environment that one feature can book for a while.

- **Free:** no `slot.yaml` here. aiplatform-a runs the baseline (the r versions from `platform/services.yaml`).
- **Booked:** a PR adds `slot.yaml` with the Jira item, owner, expiry date and the versions of the services under test. Every other service stays on the baseline.
- **Released:** a PR deletes `slot.yaml` when the feature is released or the slot expires. aiplatform-a goes back to the baseline.

One slot at a time. If `slot.yaml` exists, the environment is taken.
