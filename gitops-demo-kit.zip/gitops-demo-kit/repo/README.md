# aip-gitops-demo

Sample GitOps config repo for **LP-3818**. It shows how day-to-day deploy work changes with GitOps, using the GenAI chain services.

Plain YAML, placeholder values only. Nothing here is deployed and no Argo CD is connected: where the flow says "Argo CD would sync", that is what happens in the target setup.

## How the flow works

```
Developer ──PR──▶ this repo (Git) ◀──watches── Argo CD ──applies──▶ OpenShift
```

- **Jenkins keeps doing CI:** build, tests, scans, image push.
- **This repo decides what runs where.** Changing a version means opening a PR.
- **After the merge,** Argo CD notices the change and syncs the environment.
- **Manual changes on the cluster** are detected (OutOfSync) and reverted to match Git.

## Layout

| Path | What it holds |
|---|---|
| `platform/services.yaml` | Which version of each service runs on r, e and aiplatform-b |
| `environments/<env>/values.yaml` | Per-environment settings (namespace, replicas, log level, Kafka) |
| `feature-slots/aiplatform-a/` | Temporary booking of aiplatform-a for one feature (`slot.yaml`) |
| `apps/<service>/deployment.yaml` | One deployment template per service |

## Rules

- Every change goes through a pull request.
- One PR, one intent: one promotion, one slot, one rollback.
- No secrets, real hostnames or real environment values in this repo.

## Scenarios

Each scenario has its own branch and PR.

### 1. Promote r → e (`scenario/1-promote-r-to-e`)

1. Open the PR.
2. The diff is one line in `platform/services.yaml`: `genai-execution-service` on e goes from `1.4.2` to `1.5.0`.
3. A teammate reviews and approves.
4. Merge.
5. Argo CD would detect the change and sync e. No Jenkins deploy job.

### 2. Feature slot (`scenario/2-feature-slot`, `scenario/2-release-slot`)

1. The PR adds `feature-slots/aiplatform-a/slot.yaml`: Jira item, owner, expiry date, versions of 3 services.
2. In review everyone sees who has aiplatform-a, why and until when.
3. Merge. Argo CD would deploy those 3 versions to aiplatform-a; the other services stay on the baseline.
4. To release, the second PR deletes `slot.yaml` (also done when the slot expires).
5. Merge. aiplatform-a goes back to the baseline (r versions).

### 3. Who changed what (`scenario/3-bad-change`)

"What broke R this morning?"

1. Open `platform/services.yaml` on the main branch.
2. Switch to **Blame**.
3. The `workflow-manager` r line points to the commit `r: workflow-manager 3.1.0`.
4. Open its PR: who changed it, when, who approved.
5. From the CLI: `git log -p -- platform/services.yaml`

### 4. Rollback (`scenario/4-rollback`)

1. Take the PR found in scenario 3.
2. Revert it: a `git revert` of that change, opened as a PR.
3. The diff puts `workflow-manager` on r back from `3.1.0` to `3.0.2`.
4. Merge.
5. Argo CD would restore the previous version on r. History keeps both the bad change and the revert.

### 5. Manual change detected, drift (`scenario/5-drift`, mock only)

1. Someone runs `oc scale deployment/genai-execution-service --replicas=5 -n demo-r`.
2. Git still says `replicas: 2` (`environments/r/values.yaml`).
3. Argo CD compares the cluster with Git and marks the app **OutOfSync**.
4. With self-heal on, it scales back to 2.
5. To keep a change like this, put it into Git with a PR.

## Outside GitOps for now

Secrets, Kafka topics and DB migrations are handled as today. The templates in `apps/` are illustrative; the tool that renders them is part of the target design (LP-3551).
