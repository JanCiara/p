# Scenario 5: manual change detected (drift)

Mock only. There is no cluster or Argo CD behind this repo.

## What happens

Git says genai-execution-service on r runs with 2 replicas (`environments/r/values.yaml`). Someone scales it by hand:

```
$ oc scale deployment/genai-execution-service --replicas=5 -n demo-r
deployment.apps/genai-execution-service scaled
```

Argo CD compares the live cluster with Git:

```
APP                          SYNC        HEALTH
genai-execution-service-r    OutOfSync   Healthy

DIFF  apps/Deployment demo-r/genai-execution-service
-  replicas: 2     (Git)
+  replicas: 5     (live)
```

With self-heal on, Argo CD syncs back to Git:

```
APP                          SYNC        HEALTH
genai-execution-service-r    Synced      Healthy     replicas: 2
```

## Takeaway

A manual fix on the cluster no longer stays there silently. Either it goes into Git through a PR, or it gets reverted.
